﻿namespace certificacao_csharp_roteiro
{
    internal interface IDictionary<T>
    {
    }
}