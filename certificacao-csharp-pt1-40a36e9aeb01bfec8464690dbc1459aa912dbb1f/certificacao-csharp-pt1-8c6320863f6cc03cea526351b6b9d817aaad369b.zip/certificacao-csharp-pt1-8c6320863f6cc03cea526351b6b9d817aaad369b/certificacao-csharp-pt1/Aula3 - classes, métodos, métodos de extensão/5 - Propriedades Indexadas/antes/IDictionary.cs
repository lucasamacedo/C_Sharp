﻿namespace certificacao_csharp_roteiro.antes
{
    internal interface IDictionary<T>
    {
    }
}